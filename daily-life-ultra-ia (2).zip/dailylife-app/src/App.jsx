import React, { useState, useEffect } from "react";
import { RECIPE_CATEGORIES, RECIPES, ADVICE_CATEGORIES, ADVICE } from "./content.js";

const THEMES = {
  emerald: "#10b981",
  blue: "#3b82f6",
  purple: "#a855f7",
  orange: "#f97316",
  pink: "#ec4899",
  red: "#ef4444",
  yellow: "#eab308",
};

const TRANSLATIONS = {
  fr: {
    appName: "Daily Life",
    appNameAccent: "Ultra",
    appNameEnd: "IA",
    nav_home: "Accueil",
    nav_ai: "IA",
    nav_promo: "Promo",
    nav_settings: "Paramètres",
    stat_tasks: "Tâches",
    stat_done: "Terminées",
    stat_left: "Restantes",
    tasks_today: "Tâches du jour",
    add_task_placeholder: "Ajouter une tâche...",
    empty_tasks: "Aucune tâche — profite !",
    delete: "Supprimer",
    ai_title: "Assistant IA",
    ai_subtitle: "Recettes et conseils, toujours disponibles",
    ai_back: "Retour",
    ai_recipes: "Recettes",
    ai_recipes_sub: "Plats, desserts, rapide et plus",
    ai_advice: "Conseils",
    ai_advice_sub: "Sommeil, bien-être, organisation",
    ai_servings: "pers.",
    ai_ingredients: "Ingrédients",
    ai_steps: "Étapes",
    promo_title: "Codes promo",
    promo_subtitle: "Tes réductions et offres du moment",
    promo_copy: "Copier",
    promo_copied: "Copié !",
    promo_expires: "Expire le",
    promo_empty: "Aucun code promo pour le moment",
    settings_title: "Paramètres",
    settings_theme: "Thème",
    settings_theme_sub: "Choisis ta couleur d'accent",
    settings_language: "Langue",
    settings_language_sub: "Choisis ta langue préférée",
    settings_data: "Données",
    settings_reset: "Réinitialiser les tâches",
    settings_reset_sub: "Supprime toutes les tâches enregistrées",
    settings_about: "À propos",
    footer: "Daily Life Ultra IA",
  },
  en: {
    appName: "Daily Life",
    appNameAccent: "Ultra",
    appNameEnd: "AI",
    nav_home: "Home",
    nav_ai: "AI",
    nav_promo: "Promo",
    nav_settings: "Settings",
    stat_tasks: "Tasks",
    stat_done: "Done",
    stat_left: "Left",
    tasks_today: "Today's tasks",
    add_task_placeholder: "Add a task...",
    empty_tasks: "No tasks — enjoy!",
    delete: "Delete",
    ai_title: "AI assistant",
    ai_subtitle: "Recipes and advice, always available",
    ai_back: "Back",
    ai_recipes: "Recipes",
    ai_recipes_sub: "Mains, desserts, quick and more",
    ai_advice: "Advice",
    ai_advice_sub: "Sleep, wellbeing, organization",
    ai_servings: "servings",
    ai_ingredients: "Ingredients",
    ai_steps: "Steps",
    promo_title: "Promo codes",
    promo_subtitle: "Your current discounts and offers",
    promo_copy: "Copy",
    promo_copied: "Copied!",
    promo_expires: "Expires",
    promo_empty: "No promo codes right now",
    settings_title: "Settings",
    settings_theme: "Theme",
    settings_theme_sub: "Choose your accent color",
    settings_language: "Language",
    settings_language_sub: "Choose your preferred language",
    settings_data: "Data",
    settings_reset: "Reset tasks",
    settings_reset_sub: "Deletes all saved tasks",
    settings_about: "About",
    footer: "Daily Life Ultra AI",
  },
  es: {
    appName: "Daily Life",
    appNameAccent: "Ultra",
    appNameEnd: "IA",
    nav_home: "Inicio",
    nav_ai: "IA",
    nav_promo: "Promo",
    nav_settings: "Ajustes",
    stat_tasks: "Tareas",
    stat_done: "Hechas",
    stat_left: "Restantes",
    tasks_today: "Tareas de hoy",
    add_task_placeholder: "Añadir una tarea...",
    empty_tasks: "Sin tareas — ¡disfruta!",
    delete: "Eliminar",
    ai_title: "Asistente IA",
    ai_subtitle: "Recetas y consejos, siempre disponibles",
    ai_back: "Volver",
    ai_recipes: "Recetas",
    ai_recipes_sub: "Platos, postres, rápido y más",
    ai_advice: "Consejos",
    ai_advice_sub: "Sueño, bienestar, organización",
    ai_servings: "pers.",
    ai_ingredients: "Ingredientes",
    ai_steps: "Pasos",
    promo_title: "Códigos promo",
    promo_subtitle: "Tus descuentos y ofertas actuales",
    promo_copy: "Copiar",
    promo_copied: "¡Copiado!",
    promo_expires: "Expira el",
    promo_empty: "No hay códigos promo por ahora",
    settings_title: "Ajustes",
    settings_theme: "Tema",
    settings_theme_sub: "Elige tu color de acento",
    settings_language: "Idioma",
    settings_language_sub: "Elige tu idioma preferido",
    settings_data: "Datos",
    settings_reset: "Reiniciar tareas",
    settings_reset_sub: "Elimina todas las tareas guardadas",
    settings_about: "Acerca de",
    footer: "Daily Life Ultra IA",
  },
};

const LANGUAGES = [
  { code: "fr", label: "Français", flag: "FR" },
  { code: "en", label: "English", flag: "EN" },
  { code: "es", label: "Español", flag: "ES" },
];

const PROMO_CODES = [
  { code: "BIENVENUE20", desc: { fr: "20% sur ta première commande", en: "20% off your first order", es: "20% en tu primer pedido" }, expires: "31/12/2026" },
  { code: "ULTRA10", desc: { fr: "10% sur tout le site", en: "10% off everything", es: "10% en todo el sitio" }, expires: "15/08/2026" },
  { code: "LIVRAISON0", desc: { fr: "Livraison gratuite dès 30€", en: "Free shipping over $30", es: "Envío gratis desde 30€" }, expires: "01/09/2026" },
  { code: "FIDELITE5", desc: { fr: "5€ offerts pour 5 commandes", en: "$5 off after 5 orders", es: "5€ de regalo tras 5 pedidos" }, expires: "30/11/2026" },
];

function useLocalState(key, initial) {
  const [value, setValue] = useState(() => {
    try {
      const stored = window.__dailylife_store?.[key];
      return stored !== undefined ? stored : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    if (!window.__dailylife_store) window.__dailylife_store = {};
    window.__dailylife_store[key] = value;
  }, [key, value]);
  return [value, setValue];
}

function IconHome({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <path d="M9 22V12h6v10" />
    </svg>
  );
}
function IconAI({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="11" width="18" height="10" rx="2" />
      <circle cx="12" cy="5" r="2" />
      <path d="M12 7v4" />
      <line x1="8" y1="16" x2="8" y2="16" />
      <line x1="16" y1="16" x2="16" y2="16" />
    </svg>
  );
}
function IconGift({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 12 20 22 4 22 4 12" />
      <rect x="2" y="7" width="20" height="5" />
      <line x1="12" y1="22" x2="12" y2="7" />
      <path d="M12 7H7.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7z" />
      <path d="M12 7h4.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z" />
    </svg>
  );
}
function IconSettings({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
  );
}
function IconBolt({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" stroke="none">
      <path d="M13 2L3 14h7l-1 8 10-12h-7l1-8z" />
    </svg>
  );
}
function IconSend({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="22" y1="2" x2="11" y2="13" />
      <polygon points="22 2 15 22 11 13 2 9 22 2" />
    </svg>
  );
}
function IconPlus({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}
function IconTrash({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
      <path d="M10 11v6" />
      <path d="M14 11v6" />
      <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
    </svg>
  );
}
function IconCheck({ size = 14 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}
function IconTag({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20.59 13.41L11 3.83A2 2 0 0 0 9.59 3.17L3 3a1 1 0 0 0-1 1l.17 6.59a2 2 0 0 0 .58 1.41l9.59 9.59a2 2 0 0 0 2.83 0l6.59-6.59a2 2 0 0 0 0-2.83z" />
      <line x1="7" y1="7.5" x2="7.01" y2="7.5" />
    </svg>
  );
}
function IconCopy({ size = 14 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="9" y="9" width="13" height="13" rx="2" />
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
    </svg>
  );
}
function IconPalette({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="13.5" cy="6.5" r=".5" />
      <circle cx="17.5" cy="10.5" r=".5" />
      <circle cx="8.5" cy="7.5" r=".5" />
      <circle cx="6.5" cy="12.5" r=".5" />
      <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z" />
    </svg>
  );
}
function IconGlobe({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <line x1="2" y1="12" x2="22" y2="12" />
      <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
    </svg>
  );
}
function IconDatabase({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <ellipse cx="12" cy="5" rx="9" ry="3" />
      <path d="M3 5v14a9 3 0 0 0 18 0V5" />
      <path d="M3 12a9 3 0 0 0 18 0" />
    </svg>
  );
}
function IconInfo({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="16" x2="12" y2="12" />
      <line x1="12" y1="8" x2="12.01" y2="8" />
    </svg>
  );
}
function IconArrowLeft({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="19" y1="12" x2="5" y2="12" />
      <polyline points="12 19 5 12 12 5" />
    </svg>
  );
}
function IconChevronRight({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="9 18 15 12 9 6" />
    </svg>
  );
}
function IconChefHat({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 13.87A4 4 0 0 1 7.41 6a5.11 5.11 0 0 1 1.05-1.54 5 5 0 0 1 7.08 0A5.11 5.11 0 0 1 16.59 6 4 4 0 0 1 18 13.87V21H6Z" />
      <line x1="6" y1="17" x2="18" y2="17" />
    </svg>
  );
}
function IconBulb({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 18h6" />
      <path d="M10 22h4" />
      <path d="M12 2a7 7 0 0 0-4 12.7V17h8v-2.3A7 7 0 0 0 12 2z" />
    </svg>
  );
}
function IconSoup({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 21a8 8 0 0 0 8-8H4a8 8 0 0 0 8 8z" />
      <path d="M5 13l1-9" />
      <path d="M19 13l-1-9" />
      <path d="M9 4v2" />
      <path d="M12 3v3" />
      <path d="M15 4v2" />
    </svg>
  );
}
function IconCake({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8" />
      <path d="M4 21h16" />
      <path d="M12 11V7" />
      <path d="M9 7c0-1 .5-2 1.5-2S12 6 12 7" />
      <path d="M9 16h6" />
    </svg>
  );
}
function IconLeaf({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 20A7 7 0 0 1 4 13c0-5 4-9 10-11 1 5 1 9-1 12-1.5 2.2-3.5 3.5-2 6z" />
      <path d="M5 21c2-3 4-5 9-9" />
    </svg>
  );
}
function IconCoffee({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 8h1a4 4 0 1 1 0 8h-1" />
      <path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4z" />
      <line x1="6" y1="2" x2="6" y2="4" />
      <line x1="10" y1="2" x2="10" y2="4" />
      <line x1="14" y1="2" x2="14" y2="4" />
    </svg>
  );
}
function IconMoon({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
    </svg>
  );
}
function IconTarget({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <circle cx="12" cy="12" r="6" />
      <circle cx="12" cy="12" r="2" />
    </svg>
  );
}
function IconHeart({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.8 1-1a5.5 5.5 0 0 0 0-7.8z" />
    </svg>
  );
}
function IconListIcon({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="8" y1="6" x2="21" y2="6" />
      <line x1="8" y1="12" x2="21" y2="12" />
      <line x1="8" y1="18" x2="21" y2="18" />
      <line x1="3" y1="6" x2="3.01" y2="6" />
      <line x1="3" y1="12" x2="3.01" y2="12" />
      <line x1="3" y1="18" x2="3.01" y2="18" />
    </svg>
  );
}

function Clock() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const hh = String(time.getHours()).padStart(2, "0");
  const mm = String(time.getMinutes()).padStart(2, "0");
  const ss = String(time.getSeconds()).padStart(2, "0");
  return (
    <div style={{
      background: "rgba(255,255,255,0.06)",
      border: "1px solid rgba(255,255,255,0.08)",
      borderRadius: 10,
      padding: "6px 14px",
      fontSize: 13,
      color: "#94a3b8",
      fontWeight: 500,
      fontVariantNumeric: "tabular-nums",
    }}>
      {hh}:{mm}:{ss}
    </div>
  );
}

export default function App() {
  const [accent, setAccent] = useLocalState("accent", "emerald");
  const [lang, setLang] = useLocalState("lang", "fr");
  const [tab, setTab] = useLocalState("tab", "home");
  const [tasks, setTasks] = useLocalState("tasks", []);
  const [newTask, setNewTask] = useState("");

  const t = TRANSLATIONS[lang];
  const accentColor = THEMES[accent];

  const doneCount = tasks.filter((x) => x.done).length;
  const leftCount = tasks.length - doneCount;

  function addTask() {
    const text = newTask.trim();
    if (!text) return;
    setTasks([...tasks, { id: Date.now(), text, done: false }]);
    setNewTask("");
  }

  function toggleTask(id) {
    setTasks(tasks.map((x) => (x.id === id ? { ...x, done: !x.done } : x)));
  }

  function deleteTask(id) {
    setTasks(tasks.filter((x) => x.id !== id));
  }

  const pageStyle = {
    minHeight: "100vh",
    background: "#0a0e1a",
    color: "#e2e8f0",
    fontFamily:
      "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    paddingBottom: 40,
  };

  return (
    <div style={pageStyle}>
      <style>{`
        * { box-sizing: border-box; }
        ::placeholder { color: #64748b; }
        input, select, button, textarea { font-family: inherit; }
        .navbtn { transition: all 0.15s ease; cursor: pointer; }
        .navbtn:hover { filter: brightness(1.1); }
        .swatch { transition: transform 0.12s ease; cursor: pointer; }
        .swatch:hover { transform: scale(1.08); }
        .task-row { transition: background 0.15s ease; }
        .scroll::-webkit-scrollbar { width: 6px; }
        .scroll::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        @media (max-width: 640px) {
          .responsive-row { flex-direction: column !important; }
          .responsive-row > * { width: 100% !important; }
        }
      `}</style>

      <div style={{ maxWidth: 960, margin: "0 auto", padding: "20px 20px 0" }}>
        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingBottom: 16, borderBottom: "1px solid rgba(255,255,255,0.08)", marginBottom: 20 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: accentColor,
              display: "flex", alignItems: "center", justifyContent: "center",
              color: "#06241a",
            }}>
              <IconBolt size={20} />
            </div>
            <div style={{ fontSize: 18, fontWeight: 700, letterSpacing: -0.3 }}>
              {t.appName} <span style={{ color: accentColor }}>{t.appNameAccent}</span> {t.appNameEnd}
            </div>
          </div>
          <Clock />
        </div>

        {/* Nav */}
        <div className="responsive-row" style={{ display: "flex", gap: 10, marginBottom: 20 }}>
          <NavButton active={tab === "home"} onClick={() => setTab("home")} accentColor={accentColor} icon={<IconHome size={17} />} label={t.nav_home} />
          <NavButton active={tab === "ai"} onClick={() => setTab("ai")} accentColor={accentColor} icon={<IconAI size={17} />} label={t.nav_ai} />
          <NavButton active={tab === "promo"} onClick={() => setTab("promo")} accentColor={accentColor} icon={<IconGift size={17} />} label={t.nav_promo} />
          <NavButton active={tab === "settings"} onClick={() => setTab("settings")} accentColor={accentColor} icon={<IconSettings size={17} />} label={t.nav_settings} />
        </div>

        {/* Content */}
        {tab === "home" && (
          <HomePage
            t={t}
            accentColor={accentColor}
            accent={accent}
            setAccent={setAccent}
            lang={lang}
            setLang={setLang}
            tasks={tasks}
            doneCount={doneCount}
            leftCount={leftCount}
            newTask={newTask}
            setNewTask={setNewTask}
            addTask={addTask}
            toggleTask={toggleTask}
            deleteTask={deleteTask}
          />
        )}
        {tab === "ai" && <AIPage t={t} accentColor={accentColor} lang={lang} />}
        {tab === "promo" && <PromoPage t={t} accentColor={accentColor} lang={lang} />}
        {tab === "settings" && (
          <SettingsPage
            t={t}
            accentColor={accentColor}
            setTasks={setTasks}
          />
        )}

        <div style={{ textAlign: "right", marginTop: 32, fontSize: 12, color: "#475569", borderTop: "1px solid rgba(255,255,255,0.06)", paddingTop: 16 }}>
          © 2026 {t.footer} ⚡
        </div>
      </div>
    </div>
  );
}

function NavButton({ active, onClick, accentColor, icon, label }) {
  return (
    <button
      className="navbtn"
      onClick={onClick}
      style={{
        flex: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        padding: "13px 16px",
        borderRadius: 12,
        border: active ? `1px solid ${accentColor}` : "1px solid rgba(255,255,255,0.08)",
        background: active ? accentColor : "rgba(255,255,255,0.03)",
        color: active ? "#06241a" : "#94a3b8",
        fontWeight: 600,
        fontSize: 14,
      }}
    >
      {icon}
      {label}
    </button>
  );
}

function Card({ children, style }) {
  return (
    <div
      style={{
        background: "rgba(255,255,255,0.03)",
        border: "1px solid rgba(255,255,255,0.08)",
        borderRadius: 14,
        padding: 20,
        marginBottom: 16,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

function StatCard({ value, label, accentColor }) {
  return (
    <Card style={{ marginBottom: 0, textAlign: "center", flex: 1 }}>
      <div style={{ display: "flex", justifyContent: "center", marginBottom: 8, color: accentColor }}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
          <ellipse cx="12" cy="12" rx="9" ry="5" />
        </svg>
      </div>
      <div style={{ fontSize: 22, fontWeight: 700, marginBottom: 4 }}>{value}</div>
      <div style={{ fontSize: 13, color: "#94a3b8" }}>{label}</div>
    </Card>
  );
}

function HomePage({ t, accentColor, accent, setAccent, lang, setLang, tasks, doneCount, leftCount, newTask, setNewTask, addTask, toggleTask, deleteTask }) {
  return (
    <div>
      <div className="responsive-row" style={{ display: "flex", gap: 16, marginBottom: 0 }}>
        <StatCard value={tasks.length} label={t.stat_tasks} accentColor={accentColor} />
        <StatCard value={doneCount} label={t.stat_done} accentColor={accentColor} />
        <StatCard value={leftCount} label={t.stat_left} accentColor={accentColor} />
      </div>

      <div style={{ height: 16 }} />

      <Card>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 18 }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", color: accentColor }}>
            <IconPalette size={16} />
          </div>
          <div style={{ fontWeight: 700, fontSize: 15 }}>{t.settings_theme}</div>
        </div>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          {Object.entries(THEMES).map(([key, color]) => (
            <button
              key={key}
              className="swatch"
              onClick={() => setAccent(key)}
              aria-label={key}
              style={{
                width: 40,
                height: 40,
                borderRadius: 10,
                background: color,
                border: accent === key ? "3px solid white" : "3px solid transparent",
                cursor: "pointer",
                outlineOffset: 2,
              }}
            />
          ))}
        </div>
      </Card>

      <Card>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 18 }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", color: accentColor }}>
            <IconGlobe size={16} />
          </div>
          <div style={{ fontWeight: 700, fontSize: 15 }}>{t.settings_language}</div>
        </div>
        <select
          value={lang}
          onChange={(e) => setLang(e.target.value)}
          style={{
            width: "100%",
            background: "rgba(255,255,255,0.05)",
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: 10,
            padding: "12px 14px",
            color: "#e2e8f0",
            fontSize: 14,
            outline: "none",
            cursor: "pointer",
          }}
        >
          {LANGUAGES.map((l) => (
            <option key={l.code} value={l.code} style={{ background: "#0a0e1a" }}>
              {l.flag} {l.label}
            </option>
          ))}
        </select>
      </Card>

      <Card>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", color: accentColor }}>
            <IconCheck size={15} />
          </div>
          <div style={{ fontWeight: 700, fontSize: 16 }}>{t.tasks_today}</div>
        </div>

        <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
          <input
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addTask()}
            placeholder={t.add_task_placeholder}
            style={{
              flex: 1,
              background: "rgba(255,255,255,0.05)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 10,
              padding: "12px 14px",
              color: "#e2e8f0",
              fontSize: 14,
              outline: "none",
            }}
          />
          <button
            onClick={addTask}
            style={{
              width: 44,
              borderRadius: 10,
              border: "none",
              background: accentColor,
              color: "#06241a",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
            }}
            aria-label="Add"
          >
            <IconPlus size={18} />
          </button>
        </div>

        {tasks.length === 0 ? (
          <div style={{ textAlign: "center", padding: "24px 0", color: "#64748b", fontSize: 14 }}>
            {t.empty_tasks} 🎉
          </div>
        ) : (
          <div>
            {tasks.map((task) => (
              <div
                key={task.id}
                className="task-row"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  padding: "10px 8px",
                  borderRadius: 8,
                  marginBottom: 4,
                }}
              >
                <button
                  onClick={() => toggleTask(task.id)}
                  aria-label="toggle"
                  style={{
                    width: 22,
                    height: 22,
                    borderRadius: 6,
                    border: task.done ? "none" : "2px solid rgba(255,255,255,0.2)",
                    background: task.done ? accentColor : "transparent",
                    color: "#06241a",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                    flexShrink: 0,
                  }}
                >
                  {task.done && <IconCheck size={13} />}
                </button>
                <div
                  style={{
                    flex: 1,
                    fontSize: 14,
                    textDecoration: task.done ? "line-through" : "none",
                    color: task.done ? "#64748b" : "#e2e8f0",
                  }}
                >
                  {task.text}
                </div>
                <button
                  onClick={() => deleteTask(task.id)}
                  aria-label={t.delete}
                  style={{
                    background: "transparent",
                    border: "none",
                    color: "#64748b",
                    cursor: "pointer",
                    padding: 4,
                    display: "flex",
                  }}
                >
                  <IconTrash size={15} />
                </button>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

function AIPage({ t, accentColor, lang }) {
  const [section, setSection] = useState(null);
  const [category, setCategory] = useState(null);
  const [item, setItem] = useState(null);

  function goHome() {
    setSection(null);
    setCategory(null);
    setItem(null);
  }
  function goSection(s) {
    setSection(s);
    setCategory(null);
    setItem(null);
  }
  function goCategory(c) {
    setCategory(c);
    setItem(null);
  }
  function goItem(i) {
    setItem(i);
  }
  function goBack() {
    if (item !== null) setItem(null);
    else if (category) setCategory(null);
    else setSection(null);
  }

  const crumbLabel =
    item !== null
      ? section === "recipes"
        ? item.title[lang] || item.title.fr
        : item.title[lang] || item.title.fr
      : category
      ? (section === "recipes" ? RECIPE_CATEGORIES : ADVICE_CATEGORIES).find((c) => c.id === category)?.label[lang]
      : section === "recipes"
      ? t.ai_recipes
      : section === "advice"
      ? t.ai_advice
      : null;

  return (
    <Card style={{ minHeight: 480 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
        <div style={{ width: 32, height: 32, borderRadius: 8, background: accentColor, display: "flex", alignItems: "center", justifyContent: "center", color: "#06241a" }}>
          <IconAI size={17} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: 16 }}>{t.ai_title}</div>
          <div style={{ fontSize: 12, color: "#94a3b8" }}>{t.ai_subtitle}</div>
        </div>
      </div>

      {section && (
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
          <button
            onClick={goBack}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 4,
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 8,
              padding: "6px 10px",
              color: "#cbd5e1",
              fontSize: 12,
              cursor: "pointer",
            }}
          >
            <IconArrowLeft size={13} />
            {t.ai_back}
          </button>
          <div style={{ fontSize: 12, color: "#64748b" }}>{crumbLabel}</div>
        </div>
      )}

      {!section && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
          <SectionTile
            onClick={() => goSection("recipes")}
            accentColor={accentColor}
            icon={<IconChefHat size={26} />}
            label={t.ai_recipes}
            sub={t.ai_recipes_sub}
          />
          <SectionTile
            onClick={() => goSection("advice")}
            accentColor={accentColor}
            icon={<IconBulb size={26} />}
            label={t.ai_advice}
            sub={t.ai_advice_sub}
          />
        </div>
      )}

      {section && !category && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 12 }}>
          {(section === "recipes" ? RECIPE_CATEGORIES : ADVICE_CATEGORIES).map((c) => (
            <button
              key={c.id}
              onClick={() => goCategory(c.id)}
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 8,
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 12,
                padding: "18px 10px",
                color: "#e2e8f0",
                cursor: "pointer",
              }}
            >
              <div style={{ color: accentColor }}>
                <CategoryIcon name={c.icon} />
              </div>
              <div style={{ fontSize: 13, fontWeight: 600 }}>{c.label[lang] || c.label.fr}</div>
            </button>
          ))}
        </div>
      )}

      {section && category && item === null && (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {(section === "recipes" ? RECIPES : ADVICE)[category].map((it, i) => (
            <button
              key={i}
              onClick={() => goItem(it)}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 10,
                padding: "14px 16px",
                color: "#e2e8f0",
                cursor: "pointer",
                textAlign: "left",
              }}
            >
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: section === "recipes" ? 4 : 0 }}>
                  {it.title[lang] || it.title.fr}
                </div>
                {section === "recipes" && (
                  <div style={{ fontSize: 12, color: "#94a3b8" }}>
                    {it.time} · {it.servings} {t.ai_servings}
                  </div>
                )}
              </div>
              <IconChevronRight size={16} />
            </button>
          ))}
        </div>
      )}

      {item !== null && section === "recipes" && (
        <RecipeDetail item={item} lang={lang} t={t} accentColor={accentColor} />
      )}

      {item !== null && section === "advice" && (
        <AdviceDetail item={item} lang={lang} accentColor={accentColor} />
      )}
    </Card>
  );
}

function SectionTile({ onClick, accentColor, icon, label, sub }) {
  return (
    <button
      onClick={onClick}
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        textAlign: "center",
        gap: 10,
        background: "rgba(255,255,255,0.04)",
        border: "1px solid rgba(255,255,255,0.08)",
        borderRadius: 14,
        padding: "28px 16px",
        color: "#e2e8f0",
        cursor: "pointer",
      }}
    >
      <div style={{ color: accentColor }}>{icon}</div>
      <div style={{ fontSize: 15, fontWeight: 700 }}>{label}</div>
      <div style={{ fontSize: 12, color: "#94a3b8" }}>{sub}</div>
    </button>
  );
}

function RecipeDetail({ item, lang, t, accentColor }) {
  const ingredients = item.ingredients[lang] || item.ingredients.fr;
  const steps = item.steps[lang] || item.steps.fr;
  return (
    <div>
      <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 6 }}>{item.title[lang] || item.title.fr}</div>
      <div style={{ fontSize: 13, color: "#94a3b8", marginBottom: 18 }}>
        {item.time} · {item.servings} {t.ai_servings}
      </div>

      <div style={{ fontSize: 13, fontWeight: 700, color: accentColor, marginBottom: 10, textTransform: "uppercase", letterSpacing: 0.5 }}>
        {t.ai_ingredients}
      </div>
      <ul style={{ margin: "0 0 20px", paddingLeft: 20, color: "#cbd5e1", fontSize: 14, lineHeight: 1.8 }}>
        {ingredients.map((ing, i) => (
          <li key={i}>{ing}</li>
        ))}
      </ul>

      <div style={{ fontSize: 13, fontWeight: 700, color: accentColor, marginBottom: 10, textTransform: "uppercase", letterSpacing: 0.5 }}>
        {t.ai_steps}
      </div>
      <ol style={{ margin: 0, paddingLeft: 20, color: "#cbd5e1", fontSize: 14, lineHeight: 1.9 }}>
        {steps.map((s, i) => (
          <li key={i} style={{ marginBottom: 6 }}>{s}</li>
        ))}
      </ol>
    </div>
  );
}

function AdviceDetail({ item, lang, accentColor }) {
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
        <div style={{ color: accentColor }}>
          <IconBulb size={20} />
        </div>
        <div style={{ fontSize: 17, fontWeight: 700 }}>{item.title[lang] || item.title.fr}</div>
      </div>
      <div style={{ fontSize: 14, color: "#cbd5e1", lineHeight: 1.8 }}>{item.text[lang] || item.text.fr}</div>
    </div>
  );
}

function CategoryIcon({ name }) {
  const size = 24;
  switch (name) {
    case "bolt":
      return <IconBolt size={size} />;
    case "soup":
      return <IconSoup size={size} />;
    case "cake":
      return <IconCake size={size} />;
    case "leaf":
      return <IconLeaf size={size} />;
    case "coffee":
      return <IconCoffee size={size} />;
    case "moon":
      return <IconMoon size={size} />;
    case "target":
      return <IconTarget size={size} />;
    case "heart":
      return <IconHeart size={size} />;
    case "list":
      return <IconListIcon size={size} />;
    default:
      return null;
  }
}

function PromoPage({ t, accentColor, lang }) {
  const [copiedCode, setCopiedCode] = useState(null);

  function copyCode(code) {
    try {
      navigator.clipboard.writeText(code);
    } catch {}
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 1800);
  }

  return (
    <div>
      <Card>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: accentColor, display: "flex", alignItems: "center", justifyContent: "center", color: "#06241a" }}>
            <IconGift size={17} />
          </div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 16 }}>{t.promo_title}</div>
            <div style={{ fontSize: 12, color: "#94a3b8" }}>{t.promo_subtitle}</div>
          </div>
        </div>
      </Card>

      {PROMO_CODES.length === 0 ? (
        <Card style={{ textAlign: "center", color: "#64748b" }}>{t.promo_empty}</Card>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 14 }}>
          {PROMO_CODES.map((p) => (
            <Card key={p.code} style={{ marginBottom: 0 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10, color: accentColor }}>
                <IconTag size={16} />
                <div style={{ fontWeight: 700, fontSize: 16, letterSpacing: 0.5, fontFamily: "monospace" }}>
                  {p.code}
                </div>
              </div>
              <div style={{ fontSize: 13, color: "#cbd5e1", marginBottom: 14, lineHeight: 1.4 }}>
                {p.desc[lang] || p.desc.fr}
              </div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <div style={{ fontSize: 11, color: "#64748b" }}>
                  {t.promo_expires} {p.expires}
                </div>
                <button
                  onClick={() => copyCode(p.code)}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    background: copiedCode === p.code ? accentColor : "rgba(255,255,255,0.06)",
                    color: copiedCode === p.code ? "#06241a" : "#e2e8f0",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: 8,
                    padding: "6px 12px",
                    fontSize: 12,
                    fontWeight: 600,
                    cursor: "pointer",
                  }}
                >
                  <IconCopy size={12} />
                  {copiedCode === p.code ? t.promo_copied : t.promo_copy}
                </button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function SettingsPage({ t, accentColor, setTasks }) {
  return (
    <div>
      <Card>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", color: accentColor }}>
            <IconDatabase size={16} />
          </div>
          <div style={{ fontWeight: 700, fontSize: 15 }}>{t.settings_data}</div>
        </div>
        <button
          onClick={() => {
            if (window.confirm(t.settings_reset + " ?")) setTasks([]);
          }}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            width: "100%",
            background: "rgba(239,68,68,0.08)",
            border: "1px solid rgba(239,68,68,0.25)",
            borderRadius: 10,
            padding: "12px 14px",
            color: "#fca5a5",
            fontSize: 14,
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          <IconTrash size={15} />
          <div style={{ textAlign: "left" }}>
            <div>{t.settings_reset}</div>
            <div style={{ fontSize: 11, fontWeight: 400, color: "#f87171", opacity: 0.8 }}>{t.settings_reset_sub}</div>
          </div>
        </button>
      </Card>

      <Card style={{ marginBottom: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", color: accentColor }}>
            <IconInfo size={16} />
          </div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15 }}>{t.settings_about}</div>
            <div style={{ fontSize: 12, color: "#94a3b8" }}>Daily Life Ultra IA — v1.0</div>
          </div>
        </div>
      </Card>
    </div>
  );
}
