export const RECIPE_CATEGORIES = [
  { id: "fast", icon: "bolt", label: { fr: "Rapide", en: "Quick", es: "Rápido" } },
  { id: "main", icon: "soup", label: { fr: "Plats", en: "Mains", es: "Platos" } },
  { id: "dessert", icon: "cake", label: { fr: "Desserts", en: "Desserts", es: "Postres" } },
  { id: "healthy", icon: "leaf", label: { fr: "Léger", en: "Healthy", es: "Ligero" } },
  { id: "breakfast", icon: "coffee", label: { fr: "Petit-déj", en: "Breakfast", es: "Desayuno" } },
];

export const RECIPES = {
  fast: [
    {
      title: { fr: "Pâtes à l'ail et à l'huile d'olive", en: "Garlic and olive oil pasta", es: "Pasta al ajo y aceite de oliva" },
      time: "12 min",
      servings: 2,
      ingredients: {
        fr: ["200g de spaghetti", "4 gousses d'ail", "5 c. à soupe d'huile d'olive", "Persil frais", "Piment en flocons (optionnel)", "Sel, poivre", "Parmesan râpé"],
        en: ["200g spaghetti", "4 garlic cloves", "5 tbsp olive oil", "Fresh parsley", "Chili flakes (optional)", "Salt, pepper", "Grated parmesan"],
        es: ["200g de espaguetis", "4 dientes de ajo", "5 cdas de aceite de oliva", "Perejil fresco", "Copos de chile (opcional)", "Sal, pimienta", "Parmesano rallado"],
      },
      steps: {
        fr: ["Faire cuire les pâtes dans l'eau bouillante salée selon le paquet.", "Émincer finement l'ail.", "Chauffer l'huile d'olive à feu doux, ajouter l'ail et le piment, cuire 2 min sans laisser brûler.", "Égoutter les pâtes en gardant un peu d'eau de cuisson.", "Mélanger les pâtes avec l'huile parfumée et un peu d'eau de cuisson.", "Ajouter persil, sel, poivre et parmesan avant de servir."],
        en: ["Cook the pasta in salted boiling water per package instructions.", "Finely slice the garlic.", "Heat olive oil on low, add garlic and chili, cook 2 min without burning.", "Drain pasta, keeping a bit of cooking water.", "Toss pasta with the flavored oil and a splash of cooking water.", "Add parsley, salt, pepper and parmesan before serving."],
        es: ["Cocina la pasta en agua salada hirviendo según el paquete.", "Corta el ajo en láminas finas.", "Calienta el aceite a fuego bajo, añade el ajo y el chile, cocina 2 min sin quemar.", "Escurre la pasta guardando un poco de agua de cocción.", "Mezcla la pasta con el aceite aromatizado y un poco de agua.", "Añade perejil, sal, pimienta y parmesano antes de servir."],
      },
    },
    {
      title: { fr: "Wrap poulet César express", en: "Express chicken caesar wrap", es: "Wrap de pollo césar exprés" },
      time: "10 min",
      servings: 2,
      ingredients: {
        fr: ["2 tortillas", "1 blanc de poulet cuit (ou rôti déjà prêt)", "Salade romaine", "Sauce césar", "Parmesan", "Croûtons"],
        en: ["2 tortillas", "1 cooked chicken breast (or rotisserie)", "Romaine lettuce", "Caesar dressing", "Parmesan", "Croutons"],
        es: ["2 tortillas", "1 pechuga de pollo cocida (o asada)", "Lechuga romana", "Salsa césar", "Parmesano", "Croutones"],
      },
      steps: {
        fr: ["Couper le poulet en lanières.", "Émincer la salade.", "Étaler une cuillère de sauce césar sur chaque tortilla.", "Ajouter poulet, salade, parmesan et croûtons.", "Rouler fermement et couper en deux."],
        en: ["Slice the chicken into strips.", "Shred the lettuce.", "Spread a spoon of caesar dressing on each tortilla.", "Add chicken, lettuce, parmesan and croutons.", "Roll tightly and cut in half."],
        es: ["Corta el pollo en tiras.", "Corta la lechuga en juliana.", "Extiende una cucharada de salsa césar en cada tortilla.", "Añade pollo, lechuga, parmesano y croutones.", "Enrolla firmemente y corta por la mitad."],
      },
    },
    {
      title: { fr: "Omelette aux légumes", en: "Vegetable omelette", es: "Tortilla de verduras" },
      time: "8 min",
      servings: 1,
      ingredients: {
        fr: ["3 œufs", "Quelques champignons", "1/2 poivron", "1 poignée d'épinards", "Sel, poivre", "Beurre"],
        en: ["3 eggs", "A few mushrooms", "1/2 bell pepper", "A handful of spinach", "Salt, pepper", "Butter"],
        es: ["3 huevos", "Unos champiñones", "1/2 pimiento", "Un puñado de espinacas", "Sal, pimienta", "Mantequilla"],
      },
      steps: {
        fr: ["Battre les œufs avec sel et poivre.", "Faire revenir les légumes coupés en petits morceaux dans le beurre 3 min.", "Verser les œufs sur les légumes.", "Cuire à feu moyen-doux 3-4 min en repliant les bords.", "Plier en deux et servir chaud."],
        en: ["Beat the eggs with salt and pepper.", "Sauté the chopped vegetables in butter for 3 min.", "Pour the eggs over the vegetables.", "Cook on medium-low for 3-4 min, folding the edges.", "Fold in half and serve hot."],
        es: ["Bate los huevos con sal y pimienta.", "Sofríe las verduras picadas en mantequilla 3 min.", "Vierte los huevos sobre las verduras.", "Cocina a fuego medio-bajo 3-4 min doblando los bordes.", "Dobla por la mitad y sirve caliente."],
      },
    },
  ],
  main: [
    {
      title: { fr: "Poulet rôti aux herbes et pommes de terre", en: "Herb roasted chicken with potatoes", es: "Pollo asado a las hierbas con patatas" },
      time: "1h15",
      servings: 4,
      ingredients: {
        fr: ["1 poulet entier", "800g de pommes de terre", "4 gousses d'ail", "Thym, romarin", "Huile d'olive", "Sel, poivre", "1 citron"],
        en: ["1 whole chicken", "800g potatoes", "4 garlic cloves", "Thyme, rosemary", "Olive oil", "Salt, pepper", "1 lemon"],
        es: ["1 pollo entero", "800g de patatas", "4 dientes de ajo", "Tomillo, romero", "Aceite de oliva", "Sal, pimienta", "1 limón"],
      },
      steps: {
        fr: ["Préchauffer le four à 200°C.", "Couper les pommes de terre en quartiers, les disposer dans un plat avec l'ail.", "Frotter le poulet d'huile d'olive, sel, poivre et herbes, glisser le citron à l'intérieur.", "Placer le poulet sur les pommes de terre.", "Enfourner 1h-1h15 en arrosant régulièrement, jusqu'à ce que le jus soit clair.", "Laisser reposer 10 min avant de découper."],
        en: ["Preheat the oven to 200°C/400°F.", "Cut potatoes into wedges, place in a dish with the garlic.", "Rub the chicken with olive oil, salt, pepper and herbs, place the lemon inside.", "Set the chicken on top of the potatoes.", "Roast 1h-1h15, basting occasionally, until juices run clear.", "Rest 10 min before carving."],
        es: ["Precalienta el horno a 200°C.", "Corta las patatas en cuartos y colócalas en una fuente con el ajo.", "Frota el pollo con aceite, sal, pimienta y hierbas, mete el limón dentro.", "Coloca el pollo sobre las patatas.", "Hornea 1h-1h15, regando de vez en cuando, hasta que el jugo salga claro.", "Deja reposar 10 min antes de cortar."],
      },
    },
    {
      title: { fr: "Curry de pois chiches", en: "Chickpea curry", es: "Curry de garbanzos" },
      time: "30 min",
      servings: 4,
      ingredients: {
        fr: ["2 boîtes de pois chiches", "1 oignon", "2 gousses d'ail", "400ml de lait de coco", "2 c. à soupe de pâte de curry", "1 boîte de tomates concassées", "Coriandre fraîche", "Riz pour servir"],
        en: ["2 cans chickpeas", "1 onion", "2 garlic cloves", "400ml coconut milk", "2 tbsp curry paste", "1 can crushed tomatoes", "Fresh coriander", "Rice to serve"],
        es: ["2 latas de garbanzos", "1 cebolla", "2 dientes de ajo", "400ml de leche de coco", "2 cdas de pasta de curry", "1 lata de tomate triturado", "Cilantro fresco", "Arroz para acompañar"],
      },
      steps: {
        fr: ["Émincer l'oignon et l'ail, faire revenir 5 min dans un peu d'huile.", "Ajouter la pâte de curry, cuire 1 min.", "Ajouter les tomates, le lait de coco et les pois chiches égouttés.", "Laisser mijoter 20 min à feu doux.", "Parsemer de coriandre fraîche et servir avec du riz."],
        en: ["Chop onion and garlic, sauté 5 min in a little oil.", "Add curry paste, cook 1 min.", "Add tomatoes, coconut milk and drained chickpeas.", "Simmer 20 min on low heat.", "Top with fresh coriander and serve with rice."],
        es: ["Pica la cebolla y el ajo, sofríe 5 min en un poco de aceite.", "Añade la pasta de curry, cocina 1 min.", "Añade el tomate, la leche de coco y los garbanzos escurridos.", "Cocina a fuego lento 20 min.", "Espolvorea cilantro fresco y sirve con arroz."],
      },
    },
    {
      title: { fr: "Saumon teriyaki et riz", en: "Teriyaki salmon and rice", es: "Salmón teriyaki con arroz" },
      time: "25 min",
      servings: 2,
      ingredients: {
        fr: ["2 pavés de saumon", "4 c. à soupe de sauce soja", "2 c. à soupe de miel", "1 c. à soupe de vinaigre de riz", "1 gousse d'ail", "Riz", "Graines de sésame"],
        en: ["2 salmon fillets", "4 tbsp soy sauce", "2 tbsp honey", "1 tbsp rice vinegar", "1 garlic clove", "Rice", "Sesame seeds"],
        es: ["2 filetes de salmón", "4 cdas de salsa de soja", "2 cdas de miel", "1 cda de vinagre de arroz", "1 diente de ajo", "Arroz", "Semillas de sésamo"],
      },
      steps: {
        fr: ["Mélanger soja, miel, vinaigre et ail écrasé pour la marinade.", "Faire mariner le saumon 10 min.", "Cuire le riz selon les instructions.", "Saisir le saumon à la poêle 3-4 min par face avec la marinade.", "Laisser la sauce réduire légèrement.", "Servir sur le riz, parsemer de sésame."],
        en: ["Mix soy, honey, vinegar and crushed garlic for the marinade.", "Marinate the salmon for 10 min.", "Cook rice per instructions.", "Sear salmon in a pan 3-4 min per side with the marinade.", "Let the sauce reduce slightly.", "Serve over rice, sprinkle with sesame."],
        es: ["Mezcla soja, miel, vinagre y ajo machacado para la marinada.", "Marina el salmón 10 min.", "Cocina el arroz según las instrucciones.", "Sella el salmón en sartén 3-4 min por lado con la marinada.", "Deja que la salsa reduzca un poco.", "Sirve sobre el arroz, espolvorea sésamo."],
      },
    },
  ],
  dessert: [
    {
      title: { fr: "Fondant au chocolat", en: "Chocolate fondant", es: "Fondant de chocolate" },
      time: "25 min",
      servings: 6,
      ingredients: {
        fr: ["200g de chocolat noir", "150g de beurre", "150g de sucre", "3 œufs", "60g de farine", "Une pincée de sel"],
        en: ["200g dark chocolate", "150g butter", "150g sugar", "3 eggs", "60g flour", "A pinch of salt"],
        es: ["200g de chocolate negro", "150g de mantequilla", "150g de azúcar", "3 huevos", "60g de harina", "Una pizca de sal"],
      },
      steps: {
        fr: ["Préchauffer le four à 180°C.", "Faire fondre le chocolat et le beurre ensemble.", "Mélanger les œufs et le sucre, puis ajouter le chocolat fondu.", "Incorporer la farine et le sel.", "Verser dans un moule beurré.", "Cuire 12-14 min : le centre doit rester fondant.", "Laisser refroidir 5 min avant de démouler."],
        en: ["Preheat oven to 180°C/350°F.", "Melt chocolate and butter together.", "Mix eggs and sugar, then add the melted chocolate.", "Fold in flour and salt.", "Pour into a buttered baking dish.", "Bake 12-14 min: the center should stay fudgy.", "Let cool 5 min before unmolding."],
        es: ["Precalienta el horno a 180°C.", "Funde el chocolate y la mantequilla juntos.", "Mezcla los huevos y el azúcar, añade el chocolate fundido.", "Incorpora la harina y la sal.", "Vierte en un molde con mantequilla.", "Hornea 12-14 min: el centro debe quedar fundente.", "Deja enfriar 5 min antes de desmoldar."],
      },
    },
    {
      title: { fr: "Crumble aux pommes", en: "Apple crumble", es: "Crumble de manzana" },
      time: "45 min",
      servings: 6,
      ingredients: {
        fr: ["5 pommes", "100g de farine", "80g de beurre froid", "80g de sucre roux", "1 c. à café de cannelle"],
        en: ["5 apples", "100g flour", "80g cold butter", "80g brown sugar", "1 tsp cinnamon"],
        es: ["5 manzanas", "100g de harina", "80g de mantequilla fría", "80g de azúcar moreno", "1 cdta de canela"],
      },
      steps: {
        fr: ["Préchauffer le four à 180°C.", "Éplucher et couper les pommes, les disposer dans un plat avec la cannelle.", "Mélanger farine, sucre et beurre froid en morceaux du bout des doigts jusqu'à obtenir un sable grossier.", "Répartir cette pâte sur les pommes.", "Cuire 30 min jusqu'à ce que le dessus soit doré."],
        en: ["Preheat oven to 180°C/350°F.", "Peel and slice apples, place in a dish with cinnamon.", "Rub flour, sugar and cold butter together with fingertips until crumbly.", "Spread the crumble mix over the apples.", "Bake 30 min until golden on top."],
        es: ["Precalienta el horno a 180°C.", "Pela y corta las manzanas, colócalas en una fuente con canela.", "Mezcla harina, azúcar y mantequilla fría con los dedos hasta obtener una textura arenosa.", "Reparte la mezcla sobre las manzanas.", "Hornea 30 min hasta que esté dorado."],
      },
    },
    {
      title: { fr: "Mousse au chocolat", en: "Chocolate mousse", es: "Mousse de chocolate" },
      time: "20 min + repos",
      servings: 4,
      ingredients: {
        fr: ["200g de chocolat noir", "4 œufs", "30g de sucre", "Une pincée de sel"],
        en: ["200g dark chocolate", "4 eggs", "30g sugar", "A pinch of salt"],
        es: ["200g de chocolate negro", "4 huevos", "30g de azúcar", "Una pizca de sal"],
      },
      steps: {
        fr: ["Faire fondre le chocolat doucement au bain-marie.", "Séparer les blancs des jaunes.", "Mélanger les jaunes au chocolat fondu tiédi.", "Monter les blancs en neige avec le sel et le sucre.", "Incorporer délicatement les blancs au chocolat en 3 fois.", "Répartir dans des verres, réfrigérer au moins 3h."],
        en: ["Melt the chocolate gently over a water bath.", "Separate egg whites from yolks.", "Mix yolks into the slightly cooled melted chocolate.", "Whisk whites to stiff peaks with salt and sugar.", "Gently fold whites into chocolate in 3 batches.", "Divide into glasses, chill at least 3h."],
        es: ["Funde el chocolate suavemente al baño maría.", "Separa las claras de las yemas.", "Mezcla las yemas con el chocolate fundido ya templado.", "Monta las claras a punto de nieve con sal y azúcar.", "Incorpora suavemente las claras al chocolate en 3 veces.", "Reparte en vasos, refrigera al menos 3h."],
      },
    },
  ],
  healthy: [
    {
      title: { fr: "Bowl quinoa, avocat et légumes", en: "Quinoa, avocado and veggie bowl", es: "Bowl de quinoa, aguacate y verduras" },
      time: "20 min",
      servings: 2,
      ingredients: {
        fr: ["150g de quinoa", "1 avocat", "1 concombre", "Tomates cerises", "Feta", "Jus de citron", "Huile d'olive"],
        en: ["150g quinoa", "1 avocado", "1 cucumber", "Cherry tomatoes", "Feta", "Lemon juice", "Olive oil"],
        es: ["150g de quinoa", "1 aguacate", "1 pepino", "Tomates cherry", "Queso feta", "Zumo de limón", "Aceite de oliva"],
      },
      steps: {
        fr: ["Cuire le quinoa selon les instructions, laisser refroidir.", "Couper avocat, concombre et tomates.", "Mélanger tous les ingrédients dans un bol.", "Assaisonner avec citron, huile d'olive, sel et poivre.", "Émietter la feta sur le dessus."],
        en: ["Cook quinoa per instructions, let it cool.", "Chop avocado, cucumber and tomatoes.", "Combine all ingredients in a bowl.", "Season with lemon, olive oil, salt and pepper.", "Crumble feta on top."],
        es: ["Cocina la quinoa según las instrucciones y deja enfriar.", "Corta el aguacate, el pepino y los tomates.", "Mezcla todos los ingredientes en un bol.", "Aliña con limón, aceite de oliva, sal y pimienta.", "Desmenuza el feta por encima."],
      },
    },
    {
      title: { fr: "Soupe de légumes maison", en: "Homemade vegetable soup", es: "Sopa de verduras casera" },
      time: "35 min",
      servings: 4,
      ingredients: {
        fr: ["2 carottes", "2 courgettes", "1 poireau", "1 pomme de terre", "1 oignon", "Bouillon de légumes", "Sel, poivre"],
        en: ["2 carrots", "2 zucchini", "1 leek", "1 potato", "1 onion", "Vegetable stock", "Salt, pepper"],
        es: ["2 zanahorias", "2 calabacines", "1 puerro", "1 patata", "1 cebolla", "Caldo de verduras", "Sal, pimienta"],
      },
      steps: {
        fr: ["Couper tous les légumes en morceaux.", "Faire revenir l'oignon 3 min dans un peu d'huile.", "Ajouter les autres légumes et le bouillon.", "Laisser mijoter 25 min jusqu'à ce que les légumes soient tendres.", "Mixer si désiré, assaisonner et servir chaud."],
        en: ["Chop all vegetables into pieces.", "Sauté the onion 3 min in a little oil.", "Add the rest of the vegetables and the stock.", "Simmer 25 min until vegetables are tender.", "Blend if desired, season and serve hot."],
        es: ["Corta todas las verduras en trozos.", "Sofríe la cebolla 3 min en un poco de aceite.", "Añade el resto de verduras y el caldo.", "Cocina a fuego lento 25 min hasta que estén tiernas.", "Tritura si lo deseas, sazona y sirve caliente."],
      },
    },
    {
      title: { fr: "Salade de poulet grillé et avocat", en: "Grilled chicken and avocado salad", es: "Ensalada de pollo a la plancha y aguacate" },
      time: "20 min",
      servings: 2,
      ingredients: {
        fr: ["2 blancs de poulet", "1 avocat", "Salade verte", "Tomates cerises", "Vinaigrette légère", "Sel, poivre, paprika"],
        en: ["2 chicken breasts", "1 avocado", "Green salad", "Cherry tomatoes", "Light vinaigrette", "Salt, pepper, paprika"],
        es: ["2 pechugas de pollo", "1 aguacate", "Ensalada verde", "Tomates cherry", "Vinagreta ligera", "Sal, pimienta, paprika"],
      },
      steps: {
        fr: ["Assaisonner le poulet avec sel, poivre et paprika.", "Griller à la poêle 6-7 min par face.", "Laisser reposer puis couper en tranches.", "Disposer la salade, tomates et avocat dans une assiette.", "Ajouter le poulet et arroser de vinaigrette."],
        en: ["Season chicken with salt, pepper and paprika.", "Grill in a pan 6-7 min per side.", "Rest, then slice.", "Arrange salad, tomatoes and avocado on a plate.", "Add the chicken and drizzle with vinaigrette."],
        es: ["Sazona el pollo con sal, pimienta y paprika.", "Cocina a la plancha 6-7 min por lado.", "Deja reposar y corta en lonchas.", "Coloca la ensalada, tomates y aguacate en un plato.", "Añade el pollo y riega con vinagreta."],
      },
    },
  ],
  breakfast: [
    {
      title: { fr: "Pancakes moelleux", en: "Fluffy pancakes", es: "Panqueques esponjosos" },
      time: "20 min",
      servings: 4,
      ingredients: {
        fr: ["250g de farine", "2 œufs", "300ml de lait", "2 c. à soupe de sucre", "1 sachet de levure chimique", "Beurre"],
        en: ["250g flour", "2 eggs", "300ml milk", "2 tbsp sugar", "1 packet baking powder", "Butter"],
        es: ["250g de harina", "2 huevos", "300ml de leche", "2 cdas de azúcar", "1 sobre de levadura química", "Mantequilla"],
      },
      steps: {
        fr: ["Mélanger farine, sucre et levure.", "Ajouter œufs et lait, fouetter jusqu'à obtenir une pâte lisse.", "Chauffer une poêle beurrée à feu moyen.", "Verser une louche de pâte, cuire 2 min par face jusqu'à coloration.", "Empiler et servir avec sirop d'érable ou fruits."],
        en: ["Mix flour, sugar and baking powder.", "Add eggs and milk, whisk until smooth.", "Heat a buttered pan on medium.", "Pour a ladle of batter, cook 2 min per side until golden.", "Stack and serve with maple syrup or fruit."],
        es: ["Mezcla harina, azúcar y levadura.", "Añade huevos y leche, bate hasta que quede liso.", "Calienta una sartén con mantequilla a fuego medio.", "Vierte un cucharón de masa, cocina 2 min por lado hasta dorar.", "Apila y sirve con sirope de arce o fruta."],
      },
    },
    {
      title: { fr: "Porridge à l'avoine et fruits", en: "Oatmeal porridge with fruit", es: "Porridge de avena con frutas" },
      time: "10 min",
      servings: 1,
      ingredients: {
        fr: ["50g de flocons d'avoine", "250ml de lait (ou lait végétal)", "1 banane", "Miel", "Fruits rouges", "Cannelle"],
        en: ["50g rolled oats", "250ml milk (or plant milk)", "1 banana", "Honey", "Berries", "Cinnamon"],
        es: ["50g de avena en hojuelas", "250ml de leche (o leche vegetal)", "1 plátano", "Miel", "Frutos rojos", "Canela"],
      },
      steps: {
        fr: ["Faire chauffer le lait dans une casserole.", "Ajouter les flocons d'avoine, cuire 5 min en remuant.", "Verser dans un bol, ajouter banane tranchée et fruits rouges.", "Arroser de miel et saupoudrer de cannelle."],
        en: ["Heat the milk in a saucepan.", "Add the oats, cook 5 min stirring.", "Pour into a bowl, add sliced banana and berries.", "Drizzle with honey and sprinkle cinnamon."],
        es: ["Calienta la leche en un cazo.", "Añade la avena, cocina 5 min removiendo.", "Vierte en un bol, añade plátano en rodajas y frutos rojos.", "Riega con miel y espolvorea canela."],
      },
    },
    {
      title: { fr: "Toast avocat et œuf poché", en: "Avocado toast with poached egg", es: "Tostada de aguacate con huevo escalfado" },
      time: "15 min",
      servings: 1,
      ingredients: {
        fr: ["2 tranches de pain complet", "1 avocat", "1 œuf", "Jus de citron", "Sel, poivre, piment"],
        en: ["2 slices wholegrain bread", "1 avocado", "1 egg", "Lemon juice", "Salt, pepper, chili flakes"],
        es: ["2 rebanadas de pan integral", "1 aguacate", "1 huevo", "Zumo de limón", "Sal, pimienta, chile"],
      },
      steps: {
        fr: ["Faire griller le pain.", "Écraser l'avocat avec citron, sel et poivre.", "Pocher l'œuf dans l'eau frémissante avec un peu de vinaigre, 3 min.", "Étaler l'avocat sur le pain.", "Déposer l'œuf poché dessus, assaisonner de piment."],
        en: ["Toast the bread.", "Mash the avocado with lemon, salt and pepper.", "Poach the egg in simmering water with a little vinegar, 3 min.", "Spread avocado on the toast.", "Top with the poached egg, season with chili flakes."],
        es: ["Tuesta el pan.", "Aplasta el aguacate con limón, sal y pimienta.", "Escalfa el huevo en agua a fuego lento con un poco de vinagre, 3 min.", "Extiende el aguacate sobre la tostada.", "Coloca el huevo escalfado encima, sazona con chile."],
      },
    },
  ],
};

export const ADVICE_CATEGORIES = [
  { id: "sleep", icon: "moon", label: { fr: "Sommeil", en: "Sleep", es: "Sueño" } },
  { id: "productivity", icon: "target", label: { fr: "Productivité", en: "Productivity", es: "Productividad" } },
  { id: "wellbeing", icon: "heart", label: { fr: "Bien-être", en: "Wellbeing", es: "Bienestar" } },
  { id: "organization", icon: "list", label: { fr: "Organisation", en: "Organization", es: "Organización" } },
];

export const ADVICE = {
  sleep: [
    {
      title: { fr: "Garde des horaires réguliers", en: "Keep a regular schedule", es: "Mantén horarios regulares" },
      text: {
        fr: "Se coucher et se lever à la même heure tous les jours, même le week-end, aide ton corps à réguler naturellement son horloge interne. Après 2-3 semaines de régularité, l'endormissement devient plus rapide et le sommeil plus profond.",
        en: "Going to bed and waking up at the same time every day, even on weekends, helps your body regulate its internal clock naturally. After 2-3 weeks of consistency, falling asleep becomes faster and sleep deeper.",
        es: "Acostarte y levantarte a la misma hora todos los días, incluso los fines de semana, ayuda a tu cuerpo a regular su reloj interno de forma natural. Tras 2-3 semanas de constancia, conciliar el sueño es más rápido y el sueño más profundo.",
      },
    },
    {
      title: { fr: "Évite les écrans avant de dormir", en: "Avoid screens before bed", es: "Evita las pantallas antes de dormir" },
      text: {
        fr: "La lumière bleue des écrans freine la production de mélatonine, l'hormone du sommeil. Essaie de couper les écrans 30 à 60 minutes avant de te coucher, et privilégie la lecture ou une activité calme à la place.",
        en: "Blue light from screens suppresses melatonin production, the sleep hormone. Try turning off screens 30 to 60 minutes before bed, and opt for reading or a calm activity instead.",
        es: "La luz azul de las pantallas frena la producción de melatonina, la hormona del sueño. Intenta apagar las pantallas 30 a 60 minutos antes de dormir y opta por leer o una actividad tranquila en su lugar.",
      },
    },
    {
      title: { fr: "Rafraîchis ta chambre", en: "Cool down your room", es: "Refresca tu habitación" },
      text: {
        fr: "Une température entre 16 et 19°C est idéale pour dormir profondément. Le corps a besoin de baisser légèrement sa température interne pour s'endormir, une chambre trop chaude perturbe ce processus.",
        en: "A temperature between 16 and 19°C (61-66°F) is ideal for deep sleep. The body needs to slightly lower its internal temperature to fall asleep, and a room that's too warm disrupts this process.",
        es: "Una temperatura entre 16 y 19°C es ideal para dormir profundamente. El cuerpo necesita bajar ligeramente su temperatura interna para dormirse, y una habitación demasiado cálida altera este proceso.",
      },
    },
    {
      title: { fr: "Limite la caféine l'après-midi", en: "Limit caffeine in the afternoon", es: "Limita la cafeína por la tarde" },
      text: {
        fr: "La caféine reste active dans le corps pendant 6 à 8 heures. Une dernière tasse après 14h peut encore perturber ton endormissement le soir, même si tu ne ressens pas d'effet stimulant direct.",
        en: "Caffeine stays active in the body for 6 to 8 hours. A last cup after 2pm can still disrupt your ability to fall asleep at night, even if you don't feel a direct stimulant effect.",
        es: "La cafeína permanece activa en el cuerpo entre 6 y 8 horas. Una última taza después de las 14h puede seguir afectando tu capacidad para dormir por la noche, incluso si no sientes un efecto estimulante directo.",
      },
    },
  ],
  productivity: [
    {
      title: { fr: "La règle des deux minutes", en: "The two-minute rule", es: "La regla de los dos minutos" },
      text: {
        fr: "Si une tâche prend moins de deux minutes, fais-la immédiatement plutôt que de la noter pour plus tard. Cela évite l'accumulation de petites tâches qui finissent par peser mentalement plus que leur durée réelle.",
        en: "If a task takes less than two minutes, do it immediately instead of noting it for later. This avoids the buildup of small tasks that end up weighing on you mentally more than their actual duration.",
        es: "Si una tarea toma menos de dos minutos, hazla de inmediato en lugar de anotarla para después. Esto evita la acumulación de pequeñas tareas que terminan pesando mentalmente más que su duración real.",
      },
    },
    {
      title: { fr: "Travaille par blocs de temps", en: "Work in time blocks", es: "Trabaja en bloques de tiempo" },
      text: {
        fr: "La technique Pomodoro propose 25 minutes de concentration suivies de 5 minutes de pause. Ce rythme aide à maintenir l'attention sans s'épuiser, et rend les grosses tâches moins intimidantes.",
        en: "The Pomodoro technique suggests 25 minutes of focus followed by a 5-minute break. This rhythm helps maintain attention without burning out, and makes big tasks feel less intimidating.",
        es: "La técnica Pomodoro propone 25 minutos de concentración seguidos de 5 minutos de descanso. Este ritmo ayuda a mantener la atención sin agotarse, y hace que las tareas grandes resulten menos intimidantes.",
      },
    },
    {
      title: { fr: "Identifie ta tâche la plus importante", en: "Identify your most important task", es: "Identifica tu tarea más importante" },
      text: {
        fr: "Chaque matin, choisis une seule tâche prioritaire à accomplir avant tout le reste. Terminer cette tâche, même si rien d'autre n'avance, donne un vrai sentiment d'avancée dans la journée.",
        en: "Each morning, pick one priority task to complete before anything else. Finishing this task, even if nothing else moves forward, gives a real sense of progress for the day.",
        es: "Cada mañana, elige una sola tarea prioritaria para completar antes que todo lo demás. Terminar esta tarea, aunque nada más avance, da una verdadera sensación de progreso en el día.",
      },
    },
    {
      title: { fr: "Regroupe les tâches similaires", en: "Batch similar tasks", es: "Agrupa tareas similares" },
      text: {
        fr: "Répondre aux emails, faire des appels, ou ranger : regrouper les tâches du même type évite le coût mental de changer constamment de contexte, ce qui te fait gagner un temps considérable sur la journée.",
        en: "Answering emails, making calls, or tidying up: grouping similar tasks avoids the mental cost of constantly switching context, saving considerable time over the day.",
        es: "Responder correos, hacer llamadas u ordenar: agrupar tareas similares evita el costo mental de cambiar constantemente de contexto, lo que ahorra bastante tiempo a lo largo del día.",
      },
    },
  ],
  wellbeing: [
    {
      title: { fr: "Respire profondément 3 fois", en: "Take 3 deep breaths", es: "Respira profundamente 3 veces" },
      text: {
        fr: "Quand le stress monte, prendre trois respirations lentes et profondes active le système nerveux parasympathique et fait baisser le rythme cardiaque en quelques secondes. C'est un outil simple, disponible partout.",
        en: "When stress rises, taking three slow, deep breaths activates the parasympathetic nervous system and lowers heart rate within seconds. It's a simple tool, available anywhere.",
        es: "Cuando el estrés sube, tomar tres respiraciones lentas y profundas activa el sistema nervioso parasimpático y baja el ritmo cardíaco en segundos. Es una herramienta simple, disponible en cualquier lugar.",
      },
    },
    {
      title: { fr: "Marche 10 minutes à l'extérieur", en: "Walk outside for 10 minutes", es: "Camina 10 minutos al aire libre" },
      text: {
        fr: "La lumière naturelle et le mouvement, même bref, améliorent l'humeur et la clarté mentale. Une courte marche après le repas aide aussi la digestion et la régulation de la glycémie.",
        en: "Natural light and movement, even brief, improve mood and mental clarity. A short walk after a meal also helps digestion and blood sugar regulation.",
        es: "La luz natural y el movimiento, incluso breve, mejoran el ánimo y la claridad mental. Una caminata corta después de comer también ayuda a la digestión y la regulación del azúcar en sangre.",
      },
    },
    {
      title: { fr: "Note trois choses positives du jour", en: "Note three good things from the day", es: "Anota tres cosas buenas del día" },
      text: {
        fr: "Le soir, écrire trois petites choses qui se sont bien passées, même minimes, entraîne le cerveau à remarquer le positif plus naturellement avec le temps. C'est une pratique simple liée à une meilleure satisfaction de vie.",
        en: "In the evening, writing down three small things that went well, even minor ones, trains the brain to notice the positive more naturally over time. It's a simple practice linked to greater life satisfaction.",
        es: "Por la noche, escribir tres pequeñas cosas que salieron bien, aunque sean menores, entrena al cerebro a notar lo positivo de forma más natural con el tiempo. Es una práctica simple ligada a una mayor satisfacción vital.",
      },
    },
    {
      title: { fr: "Hydrate-toi régulièrement", en: "Stay hydrated regularly", es: "Hidrátate regularmente" },
      text: {
        fr: "Une légère déshydratation suffit à provoquer fatigue, maux de tête et baisse de concentration. Garder une bouteille d'eau à portée de main toute la journée est l'un des gestes les plus simples pour le bien-être général.",
        en: "Even mild dehydration can cause fatigue, headaches and reduced concentration. Keeping a water bottle within reach all day is one of the simplest habits for overall wellbeing.",
        es: "Una deshidratación leve basta para provocar fatiga, dolores de cabeza y menor concentración. Tener una botella de agua a mano todo el día es uno de los gestos más simples para el bienestar general.",
      },
    },
  ],
  organization: [
    {
      title: { fr: "Vide ta tête sur papier", en: "Get it all out on paper", es: "Vacía tu mente en papel" },
      text: {
        fr: "Écrire toutes les tâches en tête, même vagues, libère de l'espace mental. Le cerveau n'a plus besoin de retenir activement chaque chose à faire, ce qui réduit le stress de fond.",
        en: "Writing down every task on your mind, even vague ones, frees up mental space. The brain no longer needs to actively hold onto each thing to do, which reduces background stress.",
        es: "Escribir todas las tareas que tienes en mente, incluso las vagas, libera espacio mental. El cerebro ya no necesita retener activamente cada cosa por hacer, lo que reduce el estrés de fondo.",
      },
    },
    {
      title: { fr: "Une seule liste, pas dix", en: "One list, not ten", es: "Una sola lista, no diez" },
      text: {
        fr: "Centraliser toutes ses tâches dans un seul endroit (comme la page Accueil de cette app) évite d'oublier des choses éparpillées entre carnets, notes et mémoire. Un seul système de confiance suffit.",
        en: "Centralizing all your tasks in one place (like this app's Home page) avoids forgetting things scattered between notebooks, notes and memory. One trusted system is enough.",
        es: "Centralizar todas las tareas en un solo lugar (como la página de inicio de esta app) evita olvidar cosas dispersas entre cuadernos, notas y memoria. Un solo sistema de confianza es suficiente.",
      },
    },
    {
      title: { fr: "Prépare la veille", en: "Prepare the night before", es: "Prepara la noche anterior" },
      text: {
        fr: "Choisir ses vêtements, préparer son sac ou planifier les trois priorités du lendemain la veille au soir réduit la charge mentale du matin et évite les décisions précipitées au réveil.",
        en: "Picking clothes, packing your bag, or planning tomorrow's three priorities the night before reduces morning mental load and avoids rushed decisions right after waking up.",
        es: "Elegir la ropa, preparar la bolsa o planificar las tres prioridades del día siguiente la noche anterior reduce la carga mental matutina y evita decisiones apresuradas al despertar.",
      },
    },
    {
      title: { fr: "Range immédiatement après usage", en: "Put things away right after use", es: "Ordena inmediatamente después de usar" },
      text: {
        fr: "Remettre un objet à sa place juste après l'avoir utilisé prend quelques secondes, mais évite l'accumulation de désordre qui demande ensuite un grand rangement fatiguant.",
        en: "Putting an item back in its place right after using it takes a few seconds, but avoids the buildup of clutter that later requires a big, tiring clean-up.",
        es: "Devolver un objeto a su lugar justo después de usarlo toma unos segundos, pero evita la acumulación de desorden que luego requiere una gran limpieza agotadora.",
      },
    },
  ],
};
